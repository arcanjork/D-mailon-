INSTRUÇÕES:

1. Suba o conteúdo para um repositório no GitHub.
2. Acesse https://render.com, crie uma conta e clique em "New Web Service".
3. Conecte seu repositório, use as configurações:

   - Build Command: npm install
   - Start Command: npm start
   - Environment: Node

4. Render gerará uma URL como:
   https://dmailon-server.onrender.com

5. No HTML da sua loja, substitua a URL de upload por:
   https://dmailon-server.onrender.com/upload