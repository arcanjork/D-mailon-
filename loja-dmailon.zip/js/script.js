// script.js
let itens = 0;
let total = 0;

function previewImage(event, imgId) {
  const file = event.target.files[0];
  const formData = new FormData();
  formData.append('imagem', file);

  fetch('https://dmailon-server.onrender.com/upload', {
    method: 'POST',
    body: formData,
  })
  .then(res => res.json())
  .then(data => {
    document.getElementById(imgId).src = data.imageUrl;
  })
  .catch(err => {
    console.error('Erro no upload:', err);
  });
}

function adicionarCarrinho(nome, preco) {
  itens++;
  total += preco;
  document.getElementById('contador').textContent = `Itens no carrinho: ${itens}`;
  document.getElementById('total').textContent = `Total: R$ ${total.toFixed(2)}`;
}

function finalizarCompra() {
  window.location.href = "formas-pagamento.html";
}